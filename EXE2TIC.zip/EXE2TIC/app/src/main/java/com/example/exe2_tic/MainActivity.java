package com.example.exe2_tic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText name;
    private EditText Lastname;
    private TextView result;
    private Button btn_ok;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.name);
        Lastname = findViewById(R.id.lastname);
        result = findViewById(R.id.result);
        btn_ok = findViewById(R.id.btn_ok);
    }

    public void scan(View v){
        String name1 = name.getText().toString();
        String lastname = Lastname.getText().toString();

        if(name1.isEmpty() && lastname.isEmpty())
            result.setText("Nome não Inserido");
        else
            result.setText("Olá " + name1 + " " + lastname);
    }
}